$("#checkboxSelectAll").click(function(){
    $("input[type=checkbox]").prop('checked', $(this).prop('checked'));
});


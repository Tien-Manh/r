Chào bạn {{$user->name}},
Bạn đã gửi yêu cầu cấp lại mật khẩu cho tài khoản của mình! <br>
Vui lòng click vào link dưới đây để tiến hành tạo lại mật khẩu mới cho tài khoản của bạn!<br>
<a href="{{$url}}">{{$url}}</a>
<br>
<strong>Lưu ý: Đường dẫn trên chỉ có tác dụng trong 3h nếu sau 3h xin vui lòng gửi lại yêu cầu</strong>


<body>
    CHÀO MỪNG BẠN MỚI

    Xin chúc mừng!

    EDIFA dành tặng bạn phần quà:

    {{$gif->content}}

    Mã quà tặng của bạn là:
    {{$code}}

    Nhận quà ngay tại www.EDIFA.vn. Chúc bạn có những giây phút mua sắm thật thoải mái cùng EDIFA!

    Một số lưu ý khi sử dụng mã quà tặng:
    • Áp dụng cho sản phẩm nguyên giá
    • Chỉ áp dụng online tại www.EDIFA.vn
    • 01 tháng kể từ ngày nhận mã voucher
    • Không áp dụng đồng thời chương trình khuyến mại khác
    Thông tin chi tiết chương trình, vui lòng xem chi tiết tại đây hoặc liên hệ hotline: 18001100 (miễn phí cuộc gọi).
</body>

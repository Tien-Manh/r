<div>
{!! $template->description !!}
</div>
